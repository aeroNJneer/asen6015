close all
clear
% constants
ymax = 10;     % y-limit for NEES/NIS plots
alpha = 0.05;  % 95% confidence
mu = 398600; % gravitational constant
omegaE = 2*pi/86400;  % angular velocity of earth
rE = 6378; % radius of earth
dt = 10;
t = 0:dt:14000;
stationNums = 1:12;
% initial conditions
x0 = 6678;
y0 = 0;
r0 = sqrt(x0^2+y0^2);
x0dot = 0;
y0dot = r0 * sqrt(mu/r0^3);
X0 = [x0, x0dot, y0, y0dot]';
omega = sqrt(mu/r0^3);          % angular velocity of satellite
A0 = getAtilde(X0);
B = [0 0; 1 0; 0 0; 0 1]; 
G = dt * B; 
% end initial conditions

%% Nonlinear model simulation
pert = [0, 0.075, 0, -0.021]';  % perturbation 
X0 = X0 +  pert;                % Define initial total state
[tout, xnl] = nlmodel(t, X0, mu, [0 0]);
xnl = xnl';                     % Take transpose
% simulate measurements
Y = {};
for i = 1:length(stationNums)
    Y = [Y; {containers.Map('KeyType', 'double','ValueType', 'any')}];
end

Y = getMeasurements(Y, tout, xnl, stationNums, 0);
generatePlots("states", tout, "Total States vs. Time, Nonlinear Dynanmics - ODE45", xnl);
generatePlots("msmt", tout,  "Nonlinear Model Data Simulation", Y );
% end of NL simulation

%% Approximate linearized simulation
% Define empty perturbation state and measurement vectors as well as zero control input
x = zeros(4, length(t));
dx = zeros(4, length(t));
u = zeros(2, length(t));

% Compute nominal trajectory as a function of true anomaly
trueAnom = omega * t;
nomX0 = [r0*cos(trueAnom); -r0*omega*sin(trueAnom); r0*sin(trueAnom); r0*omega*cos(trueAnom)];

% Initialize perturbation and total state
dx(:, 1) = [0, 0.075, 0, -0.021]';
x(:, 1) = nomX0(:,1) + dx(:,1);

% Initialize array of tracking data maps and specify which stations I want to use
trackingData = {};
for i = 1:length(stationNums)
    trackingData = [trackingData; {containers.Map('KeyType', 'double','ValueType', 'any')}];
end

% Run simulation
for i = 2:length(t)
    % Compute perturbation states
    F = eye(4) + getAtilde(nomX0(:, i-1))*dt;
    dx(:, i) = F*dx(:, i-1) + G*u(:, i-1);

    % Compute total states
    x(:, i) = nomX0(:, i) + dx(:,i);

    % Compute measurement perturbations for each station
    for j = 1:length(stationNums)
        % Identify the current station's state vector
        stationID = stationNums(j);
        stationState = getStationState(t(i), stationID);

        % Compute satellite elevation angle and station angle using truth
        % (ODE45) data when satellite actually becomes visible
        satElevation = atan2(xnl(3, i)-stationState(3), xnl(1, i)-stationState(1));
        stationTheta = atan2(stationState(3), stationState(1));

        % Compute angle between satellite and tracking station
        angleDiff = satElevation - stationTheta;
        angleDiff = abs(mod((angleDiff + pi), 2*pi) - pi);

        % Check to see if satellite is visible to station
        if angleDiff <= pi/2
            % Compute nominal measurement
            nomMeas = getNLMeasurement(t(i), nomX0(:, i), stationID);

            % Compute a measurement for station j at time t(i)
            Htilde = getHtilde(nomX0(:, i), stationState);
            dy = Htilde*dx(:, i);
            
            % Query station map, add tracking data, and return to map array
            stationData = trackingData{find(stationNums==stationID)};
            % Data is measurement in first column and Htilde is
            % right-appended.
            stationData(t(i)) = [nomMeas+dy Htilde];
            trackingData{find(stationNums==stationID)} = stationData;
        end
    end
end

% Plot
% plotLinearizedData(t,x,dx,xnl,trackingData);
generatePlots("states", t, "Total States vs. Time, Linearized DT SS Model", x );
generatePlots("states", t,"Approx Perturbations vs. Time, Linearized DT SS Model", dx );
generatePlots("states", t, "State Error vs. Time, Linearized DT SS Model vs. ODE45", x-xnl);
generatePlots("msmt", t, "Approximate Linearized Model Data Simulation", trackingData );

%% LKF Implementation
% Tuning inputs
rng(100);
numTrials = 10;
givenData = load('orbitdeterm_finalproj_KFdata.mat');
Qkf = eye(2)*5e-2;
pPlus0 = diag([.1 .001 .1 .001]);    % Selected such that the satellite doesn't crash into Earth

% Setup
stationNums = 1:12;
dt = 10;
t = 0:dt:14000;
r0 = 6678;
mu = 398600;
nomX0 = [r0; 0; 0; sqrt(mu/r0)];
gamma = [0 0; 1 0; 0 0; 0 1]; 
omegaTilde = dt * gamma; 
alpha = .05;

% Initialize outputs. Each row is a different trial
filteredPerturbations = {};
filteredTotalStates = {};
truthTotalStates = {};
simulatedMeasurements = {};
estimationErrs = {};
estimationErrsCov = {};
measInnovations = {};
measInnovationsCov = {};
NEES = {};
NIS = {};
for i = 1:numTrials
    disp(['Running LKF trial ' int2str(i) '...']);
    % Initialize priors
    dxPlus = zeros(4,1);
    pPlus = pPlus0;    % Selected such that the satellite generally stays outside the Earth
    Sv = chol(pPlus, 'lower');

    % Draw intial state with perturbation and conduct truth model sim
    X0 = nomX0 + Sv * randn(size(Sv, 1), 1);
    [nomX, nomY] = simulateTruthModel(t, nomX0, zeros(2), zeros(3), stationNums);
    [truthX, measY] = simulateTruthModel(t, X0, givenData.Qtrue, givenData.Rtrue, stationNums);
    
    % Initialize this run's outputs
    trialPerturbations = {};
    trialTotalStates = {};
    trialEstimationErrs = {};
    trialEstimationErrsCov = {};
    trialMeasInnovations = {};
    trialMeasInnovationsCov = {};
    trialNEES = {};
    trialNIS = {};

    % Begin LKF filtering
    for j = 2:length(t)
        % Update step
        Ftilde = eye(4) + getAtilde(nomX(:, j-1))*dt;
        dxMinus = Ftilde*dxPlus;
        pMinus = Ftilde*pPlus*Ftilde' + omegaTilde*Qkf*omegaTilde';
        
        % Get stacked station measurements
        [y, stationIDs] = getStackedMeasAtTime(t(j), measY);
        yStar = [];
        HtildeStacked = [];
        RStacked = [];

        if ~isempty(y)
            % If there are measurements, then perform correction step by
            % stacking nominal measurements y* and getting corresponding
            % stacked Htilde and R matrices
            for k=1:length(stationIDs)
                yStar = [yStar; getNLMeasurement(t(j), nomX(:, j), stationIDs(k))];
                HtildeStacked = [HtildeStacked; getHtilde(nomX(:, j), getStationState(t(j), stationIDs(k)))];
                RSize = size(givenData.Rtrue, 1);   % R is square
                RStacked = [RStacked [zeros((k-1)*RSize, RSize); givenData.Rtrue; zeros((length(stationIDs)-k)*RSize, RSize)]];
            end
    
            % Compute Kalman gain
            K = pMinus * HtildeStacked' / (HtildeStacked*pMinus*HtildeStacked' + RStacked);
    
            % Update estimation error covariance and compute measurement
            % innovation as well as new perturbation state
            pPlus = (eye(size(K, 1))-K*HtildeStacked)*pMinus;
            dy = y-yStar;
            dxPlus = dxMinus + K * (y-yStar - HtildeStacked*dxMinus);

            % Compute measurement innovation covariance matrix
            S = HtildeStacked*pMinus*HtildeStacked' + RStacked;
        else
            % No measurements available, so carry forward pMinus and state
            pPlus = pMinus;
            dxPlus = dxMinus;

            % dy and S are null
            dy = [nan; nan; nan];
            S = [nan nan nan; nan nan nan; nan nan nan];
        end
        
        % Store outputs
        trialPerturbations = [trialPerturbations dxPlus];
        trialTotalStates = [trialTotalStates nomX(:, j)+dxPlus];
        trialEstimationErrs = [trialEstimationErrs truthX(:, j)-trialTotalStates{:, end}];
        trialEstimationErrsCov = [trialEstimationErrsCov pPlus];
        trialMeasInnovations = [trialMeasInnovations dy];
        trialMeasInnovationsCov = [trialMeasInnovationsCov S];
        trialNEES = [trialNEES (truthX(:, j)-trialTotalStates{:, end})' * (pPlus)^(-1) * (truthX(:, j)-trialTotalStates{:, end})];
        trialNIS = [trialNIS dy'*(S)^(-1)*dy];
    end

    % Store trial output
    filteredPerturbations = [filteredPerturbations; trialPerturbations];
    filteredTotalStates = [filteredTotalStates; trialTotalStates];
    truthTotalStates = [truthTotalStates; truthX];
    simulatedMeasurements = [simulatedMeasurements; measY'];
    estimationErrs = [estimationErrs; trialEstimationErrs];
    estimationErrsCov = [estimationErrsCov; trialEstimationErrsCov];
    measInnovations = [measInnovations; trialMeasInnovations];
    measInnovationsCov = [measInnovationsCov; trialMeasInnovationsCov];
    NEES = [NEES; trialNEES];
    NIS = [NIS; trialNIS];
end


% Plot typical simulation from first sim run
generatePlots("states", t, "Noisy Truth States vs. Time, Typical LKF Run", truthTotalStates{1, :});
generatePlots("states", t(2:end), "Filtered States vs. Time, Typical LKF Run", cell2mat(filteredTotalStates(1, :)));
generatePlots("msmt", t, "Noisy Simulated Measurements, Typical LKF Run", simulatedMeasurements(1, :));
generatePlots("errors", t, "State Estimation Errors vs. Time, Typical LKF Run", cell2mat(estimationErrs(1, :)), cell2mat(estimationErrsCov(1,:)))
% plot NEES/NIS
ymax = 40;
plotNeesNis(t, NEES, NIS, alpha, numTrials, 'NEES/NIS plots for LKF', length(t), ymax, ymax)

%% EKF Implementation
% Tuning inputs
rng(100);
numTrials = 1;
sim = false;
givenData = load('orbitdeterm_finalproj_KFdata.mat');
Qkf = eye(2)*1e-10;
R = givenData.Rtrue;
alpha = 0.05;
pPlus0 = diag([.1 .001 .1 .001]);    % Selected such that the satellite doesn't crash into Earth
% Setup
stationNums = 1:12;
dt = 10;
t = 0:dt:14000;
r0 = 6678;
mu = 398600;
nomX0 = [r0; 0; 0; sqrt(mu/r0)];    % initial conditions w/no noise
gamma = [0 0; 1 0; 0 0; 0 1]; 
omegaTilde = dt * gamma; 

% Initialize outputs. Each row is a different trial
filteredPerturbations = {};
filteredTotalStates = {};
truthTotalStates = {};
simulatedMeasurements = {};
estimationErrs = {};
estimationErrsCov = {};
measInnovations = {};
measInnovationsCov = {};
% trialNEES = {};
% trialNIS = {};
NEES = {};
NIS = {};

for i = 1:numTrials
    disp(['Running EKF trial ' int2str(i) '...']);
    [trialTotalStates, trialEstimationErrs, trialEstimationErrsCov, trialMeasInnovations, trialMeasInnovationsCov, xnoisy, measY, trialNEES, trialNIS] = EKF (t, nomX0, pPlus0, Qkf, R, omegaTilde, givenData, dt, stationNums, sim);
    % Store trial output
    filteredTotalStates = [filteredTotalStates; trialTotalStates];
    truthTotalStates = [truthTotalStates; xnoisy];
    simulatedMeasurements = [simulatedMeasurements; measY'];
    estimationErrs = [estimationErrs; trialEstimationErrs];
    estimationErrsCov = [estimationErrsCov; trialEstimationErrsCov];
    measInnovations = [measInnovations; trialMeasInnovations];
    measInnovationsCov = [measInnovationsCov; trialMeasInnovationsCov];
    NEES = [NEES; trialNEES];
    NIS = [NIS; trialNIS];
end

if(sim)
    run = "Monte Carlo";
else
    run = "ydata";
end
ymax = 10;
% Plot typical simulation from first sim run
generatePlots("states", t(2:end), strcat("Filtered States vs. Time, ", run, " EKF Run"), cell2mat(trialTotalStates(1, :)));
generatePlots("2sigma", t,strcat("2 sigma Estimation Errors vs. Time, ", run, " EKF Run" ), cell2mat(estimationErrsCov(1,:)) )
if(sim)
    generatePlots("errors", t, strcat("State Estimation Errors vs. Time, ", run, " EKF Run" ), cell2mat(estimationErrs(1, :)), cell2mat(estimationErrsCov(1,:)));
    generatePlots("innov", t, strcat("Measurement Innovations, ", run, " EKF Run"), measInnovations);
    % plot NEES/NIS
    plotNeesNis(t,NEES,NIS, alpha, numTrials, 'NEES and NIS plots for EKF' , length(t)*dt, ymax, ymax)
end 
%% Unknown Data LKF Run
% Tuning inputs
numTrials = 1;
givenData = load('orbitdeterm_finalproj_KFdata.mat');
Qkf = eye(2)*5e-2;
pPlus0 = diag([.1 .001 .1 .001]);    % Selected such that the satellite doesn't crash into Earth
alpha = 0.05;
% Setup
stationNums = 1:12;
dt = 10;
t = 0:dt:14000;
r0 = 6678;
mu = 398600;
nomX0 = [r0; 0; 0; sqrt(mu/r0)];
gamma = [0 0; 1 0; 0 0; 0 1]; 
omegaTilde = dt * gamma; 
numTrials = 1;
% Initialize outputs. Each row is a different trial
lkfPerturbations = [];
lkfTotalStates = [];
lkfEstimationErrsCov = [];
actualMeasurements = [];
NEES = [];
NIS = [];
% Initialize priors
dxPlus = zeros(4,1);
pPlus = pPlus0;    % Selected such that the satellite generally stays outside the Earth
Sv = chol(pPlus, 'lower');

% Draw intial state with perturbation and conduct truth model sim
X0 = nomX0 + Sv * randn(size(Sv, 1), 1);
[nomX, nomY] = simulateTruthModel(t, nomX0, zeros(2), zeros(3), stationNums);
measY = parseGivenData(givenData.tvec, givenData.ydata);

% Begin LKF filtering
for j = 2:length(t)
    % Update step
    Ftilde = eye(4) + getAtilde(nomX(:, j-1))*dt;
    dxMinus = Ftilde*dxPlus;
    pMinus = Ftilde*pPlus*Ftilde' + omegaTilde*Qkf*omegaTilde';
    
    % Get stacked station measurements
    [y, stationIDs] = getStackedMeasAtTime(t(j), measY);
    yStar = [];
    HtildeStacked = [];
    RStacked = [];

    if ~isempty(y)
        % If there are measurements, then perform correction step by
        % stacking nominal measurements y* and getting corresponding
        % stacked Htilde and R matrices
        for k=1:length(stationIDs)
            yStar = [yStar; getNLMeasurement(t(j), nomX(:, j), stationIDs(k))];
            HtildeStacked = [HtildeStacked; getHtilde(nomX(:, j), getStationState(t(j), stationIDs(k)))];
            RSize = size(givenData.Rtrue, 1);   % R is square
            RStacked = [RStacked [zeros((k-1)*RSize, RSize); givenData.Rtrue; zeros((length(stationIDs)-k)*RSize, RSize)]];
        end

        % Compute Kalman gain
        K = pMinus * HtildeStacked' / (HtildeStacked*pMinus*HtildeStacked' + RStacked);

        % Update estimation error covariance and compute measurement
        % innovation as well as new perturbation state
        pPlus = (eye(size(K, 1))-K*HtildeStacked)*pMinus;
        dy = y-yStar;
        dxPlus = dxMinus + K * (y-yStar - HtildeStacked*dxMinus);
        % Compute measurement innovation covariance matrix
        S = HtildeStacked*pMinus*HtildeStacked' + RStacked;

    else
        % No measurements available, so carry forward pMinus and state
        pPlus = pMinus;
        dxPlus = dxMinus;

        % dy and S are null
        dy = [nan; nan; nan];
        S = [nan nan nan; nan nan nan; nan nan nan];
    end
    
    % Store outputs
    lkfPerturbations = [lkfPerturbations dxPlus];
    lkfTotalStates = [lkfTotalStates nomX(:, j)+dxPlus];
    lkfEstimationErrsCov = [lkfEstimationErrsCov pPlus];
    actualMeasurements = [actualMeasurements; measY'];
    NEES = [NEES (truthX(:, j)-trialTotalStates{:, end})' * (pPlus)^(-1) * (truthX(:, j)-trialTotalStates{:, end})];
    NIS = [NIS dy'*(S)^(-1)*dy];
end

% Plot typical simulation from first sim run
generatePlots("states", t(2:end), "Filtered Total States vs. Time, ydata LKF Run", lkfTotalStates);
generatePlots("states", t(2:end), "Filtered Perturbations vs. Time, ydata LKF Run", lkfPerturbations);

% Plot 2sigma cov
    figure;
    twoSigma1 = [];
    for i = 1:size(lkfEstimationErrsCov, 2)/size(lkfEstimationErrsCov, 1)
        twoSigma1 = [twoSigma1 2*sqrt(lkfEstimationErrsCov(1,i*size(lkfEstimationErrsCov, 1)-3))];
    end
    subplot(4,1,1);
    hold on;
    plot(t(2:end), twoSigma1);
    sgtitle('State Estimation Error +2\sigma Bounds vs. Time, ydata LKF Run');
    ylabel('X 2\sigma Bound [km]');
    hold off;

    twoSigma2 = [];
    for i = 1:size(lkfEstimationErrsCov, 2)/size(lkfEstimationErrsCov, 1)
        twoSigma2 = [twoSigma2 2*sqrt(lkfEstimationErrsCov(2,i*size(lkfEstimationErrsCov, 1)-2))];
    end
    subplot(4,1,2);
    hold on;
    plot(t(2:end), twoSigma2);
    ylabel('Xdot 2\sigma Bound [km/s]');
    hold off;

    twoSigma3 = [];
    for i = 1:size(lkfEstimationErrsCov, 2)/size(lkfEstimationErrsCov, 1)
        twoSigma3 = [twoSigma3 2*sqrt(lkfEstimationErrsCov(3,i*size(lkfEstimationErrsCov, 1)-1))];
    end
    subplot(4,1,3);
    hold on;
    plot(t(2:end), twoSigma3);
    ylabel('Y 2\sigma Bound [km]');
    hold off;

    twoSigma4 = [];
    for i = 1:size(lkfEstimationErrsCov, 2)/size(lkfEstimationErrsCov, 1)
        twoSigma4 = [twoSigma4 2*sqrt(lkfEstimationErrsCov(4,i*size(lkfEstimationErrsCov, 1)))];
    end
    subplot(4,1,4);
    hold on;
    plot(t(2:end), twoSigma4);
    ylabel('Ydot 2\sigma Bound [km/s]');
    xlabel('Time t (s)');
    hold off;