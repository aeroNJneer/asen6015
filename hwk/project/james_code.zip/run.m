
% ASEN-6015 FINAL PROJECT
% NICOLE JAMES

clear;
close all;
% set up graphics
set(0,'DefaultAxesXGrid','on', ...
    'DefaultAxesYGrid','on', ...
    'DefaultLineLineWidth',2, ...
    'DefaultAxesLineWidth',1.5);
set(groot, 'defaultAxesFontSize',12, ...
    'defaultTextFontSize',12, ...
    'defaultLegendFontSize',14, ...
    'defaultAxesTitleFontSizeMultiplier', 1.5, ...
    'defaultAxesTitleFontSizeMultiplier', 1.2);


LTT = LowThrustTransfer;
% CONSTANTS
%  WATT = kg m^2/s^3  Isp = sec  
% Simulation parameters
thrust_params.power = 10e3;           % 10 kW
thrust_params.Isp = 3300;             % Specific impulse
thrust_params.efficiency = 0.65;      % Engine efficiency
thrust_params.initial_mass = 1200;    % kg
thrust_params.mu = LowThrustTransfer.mu;
thrust_params.initial_tw = 3.4e-2;    % thrust in mN (?)          
thrust_params.thrust_acceleration = 2*thrust_params.power*thrust_params.efficiency/(LTT.g0 * thrust_params.Isp);
thrust_params.mass_flow_rate = 2*thrust_params.efficiency* thrust_params.power/(LowThrustTransfer.g0*thrust_params.Isp)^2; 
secondsperday = 24*3600;

% Phase 1 and 2 guidance parameters  
guidance_params.phase1.Ke0 = 0;
guidance_params.phase1.Ke1 = -1.5e-3/secondsperday;
guidance_params.phase1.Ke2 = 0/secondsperday^2;
guidance_params.phase1.Ki0 = -0.33;
guidance_params.phase1.Ki1 = -4.3e-3/secondsperday;

guidance_params.phase2.Ke0 = -0.18;
guidance_params.phase2.Ke1 = -1.0e-2/secondsperday;
guidance_params.phase2.Ke2 = 7e-5/secondsperday^2;
guidance_params.phase2.Ki0 = -0.85;
guidance_params.phase2.Ki1 = -5.2e-3/secondsperday;

% INITIAL CONDITIONS

initial_altitude = 550e3;  
initial_inclination = deg2rad(28.5);
r_earth = 6378e3;  % Earth radius
r_initial = [r_earth + initial_altitude; 0; 0 ];
v_initial = [0; sqrt(LTT.mu / norm(r_initial)); 0];

% Initial states - assume simulation starts at RAAN
rtn2eci = Euler313(0, initial_inclination, 0, 0);
r0 = rtn2eci * r_initial;
v0 = rtn2eci * v_initial;

% TARGET CONDITIONS

% Target GEO conditions
target_semimajor_axis = 42164e3;
vf = sqrt(LTT.mu/target_semimajor_axis);

results = LTT.simulate_transfer(r0, v0, target_semimajor_axis, thrust_params, guidance_params);

aef = results.a(end) - target_semimajor_axis
t = results.time(end)/24/3600

%% Plot results
    figure;
    subplot(2,1,1);
    plot([results.time]/24/3600 , vecnorm(results.states(:,1:3), 2, 2)/1000);
    title('Radius vs Time');
    xlabel('Time (days)');
    ylabel('Altitude [km]');
    
    subplot(2,1,2);
    plot(results.time/24/3600 , results.states(:,7));
    title('Spacecraft Mass vs Time');
    xlabel('Time [days]');
    ylabel('Mass [kg]');
    
    figure;
    subplot(3,1,1);
    plot(results.time/24/3600 , results.a/1000);
    title('Semi-major Axis vs Time');
    xlabel('Time (days)');
    ylabel('Semi-major Axis ({\i a}) [km]', 'Interpreter','latex');
    
    subplot(3,1,2);
    plot(results.time/24/3600 , results.ecc);
    title('Eccentricity vs Time');
    xlabel('Time [days]');
    ylabel('Eccentricity ');
    
    subplot(3,1,3);
    plot(results.time/24/3600 , results.inc);
    title('Inclination vs Time');
    xlabel('Time (days)');
    ylabel('Inclination {\i i} [deg]','Interpreter','latex');
    
    
    figure;
    plot3(results.states(:,1)/1000,results.states(:,2)/1000,results.states(:,3)/1000)
    xlabel('X (km)')
    ylabel('Y (km)')
    zlabel('Z (km)')
    title('History of Transfer Orbit (Nominal)')
    
    
    figure;
    plot(results.a,results.ecc)
    ylim([0 0.01])
    title('Eccentricity vs Semi-major Axis (Nominal)')
    ylabel('Eccentricity {\i e}', 'Interpreter','latex')
    xlabel('Semi-major Axis {\i a} [km]', 'Interpreter','latex')
    
    figure;
    plot(results.a, rad2deg(results.inc))
    title('Inclination vs Semi-major Axis (Nominal)')
    ylabel('Inclination (\iti [deg]')
    title('Orbit Inclination')
    xlabel('Semi-major Axis \ita [km]')
    hold off;
    
    
    figure;
    subplot(3,1,1);
    plot(results.time/24/3600 , rad2deg(results.angles(:,1)));
    title('Pitch Angle vs Time');
    xlabel('Time (days)');
    ylabel('Pitch \alpha [deg]');
    
    subplot(3,1,2);
    plot(results.time/24/3600 , rad2deg(results.angles(:,2)));
    title('Yaw Angle vs Time');
    xlabel('Time (days)');
    ylabel('Yaw Angle \beta [deg]');
    
    subplot(3,1,3);
    plot(results.time/24/3600 , rad2deg(results.angles(:,3)));
    title('Flight Path Angle vs Time');
    xlabel('Time (days)');
    ylabel('Flight Path Angle \gamma [deg]');
    
    figure;
    plot(results.true_anomaly , rad2deg(results.angles(:,2)));
    title('Yaw Angle vs True Anomaly');
    xlabel('True Anomaly (rad)');
    ylabel('Yaw Angle \beta [rad]');

%% Monte Carlo simulations

% 3 sigma error = 10%
num_sims = 50;
sigma_error = 0.05/3; 
error_param = "mass flow rate";

% INITIAL CONDITIONS

% error in m_dot, Isp, thrust = 5-10% ; input power = 3-7%
resultsMc = runMonteCarlo(num_sims, sigma_error, error_param, r0, v0, target_semimajor_axis, thrust_params, guidance_params,LTT);

% calculate statistics
% mean, std, final values, histogram distributions

for i = 1:num_sims
    a_final(i) = resultsMc(i).a(end);
    e_final(i) = resultsMc(i).ecc(end);
    i_final(i) = resultsMc(i).inc(end);
    t_final(i) = resultsMc(i).time(end);
    m_final(i) = resultsMc(i).states(end,7);
end

std_a = std(a_final);
mean_a = mean(a_final);
std_e = std(e_final);
mean_e = mean(e_final);
std_i = std(i_final);
mean_i = mean(i_final);
std_t = std(t_final)
mean_t = mean(t_final);
std_m = std(m_final);
mean_m = std(m_final);

a_errors = a_final - target_semimajor_axis;
mean_a_errors = mean(a_errors);
std_a_errors = std(a_errors);

   % plot results

    figure;
    histogram(a_errors/1000,num_sims/2);
    title('Semi-major Axis Error');
    xlabel('SMA (\ita) Error (km)');
    ylabel('Count');
    grid on;

    figure;
    histogram(e_final, num_sims/2);
    title('Eccentricity Error');
    xlabel('Eccentricity (\ite) Error');
    ylabel('Count');
    grid on;

    figure;
    histogram(rad2deg(i_final),num_sims/2);
    title('Inclination Error');
    xlabel('Inclination (\iti) Error (deg)');
    ylabel('Count');
    grid on;

    figure;
    histogram(m_final,num_sims/2);
    title('Final Mass of Propellant');
    xlabel('Mass of Propellant (kg)');
    ylabel('Count');
    grid on;

    figure;
    histogram(t_final/24/3600,num_sims/2);
    title('Transfer Time');
    xlabel('Transfer Time (days)');
    ylabel('Count');
    grid on;

function results = runMonteCarlo(num_sims, sigma_err, error_param, r0, v0, target_semimajor_axis, thrust_params, guidance_params, LTT)

    % Run Monte Carlo simulations
    for i = 1:num_sims
        % Generate random thrust scaling (+/- sigma) for this simulation

        noise = (-1 + 2*rand)*sigma_err;

        thrust_params.mass_flow_rate = thrust_params.mass_flow_rate + thrust_params.mass_flow_rate*noise;
        results(i) = LTT.simulate_transfer(r0, v0, target_semimajor_axis, thrust_params, guidance_params);
    %    results(i).error = noise;
    end
end
